//Filename: BurmaShave.java
//Written by: Jon O'Dowd
//Written on: 06/23/2018

import javax.swing.JOptionPane;

public class BurmaShave
{
   public static void main(String[] args)
   {
      JOptionPane.showMessageDialog(null, "Shaving brushes");
      JOptionPane.showMessageDialog(null, "Such a bother");
      JOptionPane.showMessageDialog(null, "Burma Shave");
      JOptionPane.showMessageDialog(null, "Looks good to Father");
   }
}