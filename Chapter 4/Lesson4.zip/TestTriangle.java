
public class TestTriangle {

	public static void main(String[] args) 
	{
		Triangle one = new Triangle(4, 5);
		one.computeC();

	}

}
