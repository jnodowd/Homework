public class Initials
{
   public static void main(String[] args)
   {
      char initial1 = 'J';
      char initial2 = 'G';
      char initial3 = 'O';
      
      System.out.println("My initials are: " + initial1 + "." + initial2 + "." + initial3 + ".");
   }
}