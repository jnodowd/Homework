//Filename: FavoriteSong.java
//Written by: Jon O'Dowd
//Written on: 06/23/2018

public class FavoriteSong
{
   public static void main(String[] args)
   {
      System.out.println("Oh what a beautiful morning,");
      System.out.println("Oh what a beautiful day,");
      System.out.println("I've got a wonderful feeling,");
      System.out.println("Everything's going my way.");
   }
}
